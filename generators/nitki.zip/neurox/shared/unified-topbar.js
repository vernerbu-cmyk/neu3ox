/* NeuroX Beta 9: a shared navigation bar for training and generator pages.
   Does not replace game-specific controls, scoreboards, or form controls. */
(function(){
  'use strict';
  const script=document.currentScript;
  const root=new URL('../', script.src);
  const sections={
    memory:'Память',attention:'Внимание',preschool:'Дошкольники',reading:'Скорочтение',
    math:'Математика',orfografos:'Орфография',generators:'Генераторы',other:'Другое'
  };
  const relative=location.pathname.startsWith(root.pathname)?decodeURI(location.pathname.slice(root.pathname.length)):'';
  const category=relative.split('/')[0];
  if(!sections[category] || relative===category+'/index.html')return;
  const folderLink=new URL(category+'/index.html',root).href;
  const homeLink=new URL('index.html',root).href;
  const fallback=(document.title||'Тренажёр').replace(/\s*[—–|-]\s*NeuroX.*$/i,'').trim();
  const item=Array.isArray(window.NEUROX_MENU)?window.NEUROX_MENU.flatMap(x=>x.items).find(x=>x.file===relative):null;
  const name=item?.title||fallback;
  const brain='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5c-3-5-9-.8-7 3-4 1-3 7 1 7-1 5 5 7 6 2 1 5 7 3 6-2 4 0 5-6 1-7 2-4-4-8-7-3z"/><path d="M12 5v14M8 9c0 3 2 3 4 3m4-3c0 3-2 3-4 3"/></svg>';
  const moon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 16a8.4 8.4 0 0 1-12-12 8.4 8.4 0 1 0 12 12z"/></svg>';
  const sun='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.4 1.4m11.34 11.34 1.4 1.4M2 12h2m16 0h2M4.93 19.07l1.4-1.4M17.67 6.33l1.4-1.4"/></svg>';
  function makeButton(icon,label){const b=document.createElement('button');b.type='button';b.className='nxub-action';b.setAttribute('aria-label',label);b.title=label;b.innerHTML=icon;return b}
  function init(){
    if(document.getElementById('nx-unified-bar'))return;
    const nav=document.createElement('div');nav.id='nx-unified-bar';nav.setAttribute('role','banner');
    ['keydown','keyup','keypress','click'].forEach(type=>nav.addEventListener(type,event=>event.stopPropagation()));
    const left=document.createElement('div');left.className='nxub-left';
    const brand=document.createElement('a');brand.className='nxub-brand';brand.href=homeLink;
    const logo=document.createElement('span');logo.className='nxub-logo';logo.innerHTML=brain;
    const titles=document.createElement('div');titles.className='nxub-titles';
    const main=document.createElement('div');main.className='nxub-main';main.textContent='NeuroX';
    const crumb=document.createElement('div');crumb.className='nxub-crumb';crumb.textContent=sections[category]+' / '+name;
    titles.append(main,crumb);brand.append(logo,titles);
    const back=document.createElement('a');back.className='nxub-section';back.href=folderLink;back.textContent='← '+sections[category];
    left.append(brand,back);
    const actions=document.createElement('div');actions.className='nxub-actions';
    if(item && window.NeuroXQuickAccess){
      const fav=makeButton('☆','Добавить в избранное');
      const sync=()=>{const marked=window.NeuroXQuickAccess.favorites().includes(item.file);fav.textContent=marked?'★':'☆';fav.setAttribute('aria-pressed',String(marked));fav.title=marked?'Убрать из избранного':'Добавить в избранное';fav.setAttribute('aria-label',fav.title)};
      fav.addEventListener('click',e=>{e.stopPropagation();window.NeuroXQuickAccess.toggle(item.file);sync()});
      window.addEventListener('storage',sync);window.addEventListener('neurox:quick-access-change',sync);sync();actions.append(fav);
    }
    const theme=makeButton(moon,'Сменить тему');
    function syncTheme(){theme.innerHTML=document.documentElement.dataset.theme==='dark'?sun:moon;theme.title=document.documentElement.dataset.theme==='dark'?'Светлая тема':'Тёмная тема';theme.setAttribute('aria-label',theme.title)}
    theme.addEventListener('click',e=>{e.stopPropagation();const next=document.documentElement.dataset.theme==='dark'?'light':'dark';window.NeuroXTheme.set(next);syncTheme()});
    new MutationObserver(syncTheme).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});syncTheme();actions.append(theme);
    const season=makeButton('','Времена года');season.id='seasonBtn';season.style.display='none';season.addEventListener('click',e=>e.stopPropagation());
    actions.append(season);
    const settings=document.createElement('a');settings.className='nxub-action';
    settings.href=new URL('index.html#settings',root).href;
    settings.title='Настройки NeuroX';settings.setAttribute('aria-label','Настройки NeuroX');
    settings.textContent='⚙';actions.append(settings);
    const menu=makeButton('☰','Открыть меню NeuroX');menu.setAttribute('aria-controls','nx-drawer');menu.setAttribute('aria-expanded','false');window.addEventListener('neurox:drawer-state',e=>menu.setAttribute('aria-expanded',String(e.detail.open)));
    menu.addEventListener('click',e=>{e.stopPropagation();const old=document.getElementById('nx-drawer-btn');if(old)old.click();else location.href=homeLink});
    actions.append(menu);
    const garland=document.createElement('div');garland.className='season-garland';garland.id='seasonGarland';garland.setAttribute('aria-hidden','true');
    nav.append(left,actions,garland);
    document.body.dataset.nxPath=relative;
    document.body.insertAdjacentElement('afterbegin',nav);document.body.classList.add('nx-unified-page');
    let height=-1;
    const resize=()=>{const next=Math.round(nav.getBoundingClientRect().height);if(next===height)return;height=next;document.documentElement.style.setProperty('--nx-nav-height',next+'px');if(['other/labyrint.html','other/labyrint2.html','preschool/findletter.html','math/findnumber.html','preschool/cave/index.html','reading/alfabet.html','reading/raduga.html','reading/chitaem/chitalka.html'].includes(relative))requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')))};
    new ResizeObserver(resize).observe(nav);resize();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
