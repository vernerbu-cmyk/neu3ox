window.NEUROX_MENU=[{id:'generators',icon:'📝',title:'Генераторы листов',items:[{icon:'🧵',title:'Нитки',file:'generators/nitki.html'}]}];
